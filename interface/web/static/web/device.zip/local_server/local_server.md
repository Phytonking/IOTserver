errors: 

`-1` = Not enough information
`-2` = Account not found on the servers.
`0` = Not logged in