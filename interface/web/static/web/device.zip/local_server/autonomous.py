from commands import *


def main():
    print("add code to autonomous")